#include "common.fx"

// Application to Vertex defined by material class
struct a2vBad {
	float4	v4Position:	POSITION;
	float4	v4Diffuse:	COLOR0;
	float2	vTexCoords:	TEXCOORD0;
};

struct a2vBadTween {
	float4	v4PositionA:POSITION;
	float4	v4DiffuseA:	COLOR0;
	float2	vTexCoordsA:	TEXCOORD0;
	float4	v4PositionB:TEXCOORD1;
	float4	v4DiffuseB:	COLOR1;
	float2	vTexCoordsB:	TEXCOORD3;
};

struct a2vBadMPS {
	float4	v4Position:	POSITION;
	float4	v4Weights:	BLENDWEIGHT;
	int4	v4Indices:	BLENDINDICES;
	float3	v3Normal:	NORMAL;
	float4	v4Diffuse:	COLOR0;
	float2	vTexCoords:	TEXCOORD0;
};

// Fragment to surface
struct f2sBad {
	float4 col:		COLOR0;
};

//////////////////////////////////////////////////////////////////
/// Ambient layer
//////////////////////////////////////////////////////////////////
struct v2fBadAmbient {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
};

float3 CalculateColor() {
	float3 Color=float3((0.5*sin(vEngineTime*4)+0.5)*0.5,0.1,0.1);
	return Color;
}

// Vertex shader
v2fBadAmbient Ambient_VS11(a2vBad IN)
{
	v2fBadAmbient OUT;

	CalcPosition(OUT.Position,IN.v4Position);
	OUT.TexDiffuse=IN.vTexCoords;
	OUT.Diffuse.rgb=CalculateColor();
	OUT.Diffuse.a=1;
	
	return OUT;
}

v2fBadAmbient AmbientTween_VS11(a2vBadTween IN)
{
	v2fBadAmbient OUT;
	
	float4 v4Position=lerp(IN.v4PositionA,IN.v4PositionB,vTweenFactor);
	float4 v4Diffuse=lerp(IN.v4DiffuseA,IN.v4DiffuseB,vTweenFactor);
	float2 vTexCoords=lerp(IN.vTexCoordsA,IN.vTexCoordsB,vTweenFactor);

	CalcPosition(OUT.Position,v4Position);
	OUT.TexDiffuse=vTexCoords;
	OUT.Diffuse.rgb=CalculateColor();
	OUT.Diffuse.a=1;
	
	return OUT;
}
// Pixel shader
f2sBad Ambient_PS11(v2fBadAmbient IN) 
{
	f2sBad OUT;
	
	OUT.col=2*IN.Diffuse;
	
	return OUT;
}

// Techniques
technique Ambient_VS11_PS11 < string Identifier="Ambient"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
	}
}

technique AmbientTween_VS11_PS11 < string Identifier="AmbientTween"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 AmbientTween_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Vertex shader
v2fBadAmbient Ambient_MPS_VS11(a2vBadMPS IN)
{
	v2fBadAmbient OUT;
	
	static const float One=1;

	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	// Calculate lighting
	OUT.Diffuse.rgb=CalculateColor();
	OUT.Diffuse.a=1;

	OUT.TexDiffuse=IN.vTexCoords;
	
	return OUT;
}

// Techniques
technique Ambient_MPS_VS11_PS11 < string Identifier="AmbientMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_MPS_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
	}
}
