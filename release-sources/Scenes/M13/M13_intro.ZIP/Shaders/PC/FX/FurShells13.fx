#include "StandardCommon.fx"

//
//	Fur shader for Shader Model 1.1 hardware
//

#if defined(SHELLSENABLED)
texture mapShells;
sampler samplerShells = sampler_state {
	texture =<mapShells>;
	minFilter=Linear;
	magFilter=Linear;
	mipFilter=Linear;
	AddressU=Wrap;
	AddressV=Wrap;
	AddressW=Wrap;
};

texture anisoMap;
sampler samplerAniso = sampler_state {
	texture =<anisoMap>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

float ShellDistance;
int ShellCount;

struct v2fFur
{
    float4 Position     : POSITION;
	float3 TexAniso		: TEXCOORD0;
	float3 TexDiffuse	: TEXCOORD1;
	float3 vLightDirTS	: TEXCOORD2;
	float3 vHalfDirTS	: TEXCOORD3;
	float4 ShellBlend	: COLOR0;
};

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/*float4 PS_Shells(v2fFur IN): COLOR
{
	float3 diffuse=tex2D(samplerDiffuse, IN.TexAniso.xy);
	float3 mask=tex2D(samplerShells, IN.TexDiffuse.xy);
	float3 v3Normal=float3(0,0,1);
	float vDiffuseIntensity=saturate(dot(v3Normal,IN.vLightDirTS));
	float vSpecularIntensity=saturate(dot(v3Normal,IN.vHalfDirTS));
//	OUT.anisoTexCoords=float3(vDiffuseIntensity,vSpecularIntensity,0);
	float2 anisoTexCoords=float2(vDiffuseIntensity,vSpecularIntensity);
	//float4 cAni=tex2D(samplerAniso,IN.anisoTexCoords.xy);
	float4 cAni=tex2D(samplerAniso,anisoTexCoords);
	diffuse*=cAni.rgb;
	return float4(diffuse.rgb,IN.ShellBlend.a*mask.r);
}*/

#if defined(MESH_STANDARD) || defined(MESH_RIGID)

v2fFur VS_Base(a2vStandard IN) 
{
    v2fFur OUT;
	
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	OUT.TexAniso.xyz=float3(IN.vTexCoords.xy,0);
	OUT.TexDiffuse.xyz=OUT.TexAniso.xyz;
	
	// the single byte pr vertex of bandwidth should prove faster to transfer, than doing NrOfShells drawcalls
	OUT.ShellBlend=(1-IN.v4Diffuse)*0.5;
	
	//calc anisotropic
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	
	
	float3 vLightDirOS=v4LightPosObject.xyz-IN.v4Position.xyz;
	
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	float3 vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+vEyeDirTS);
	
    return OUT;
}

technique FurShells < string Identifier="FurShells";//string Performance="Fastest"; 
> {
	pass Shell
    {		
		VertexShader = compile vs_1_1 VS_Base();
		PixelShader  = asm {	//compile ps_1_1 PS_Shells();
			ps.1.1
			
			tex t0 ; Contains direction of anisotropy in tangent space
			tex t1 ; diffuse base map w. shells hairinfo in alpha
			texm3x2pad t2, t0_bx2	; Perform first row of matrix multiply.
			texm3x2tex t3, t0_bx2	; Perform second row of matrix multiply to get a
									; 3-vector with which to sample texture 3, which is
									; a look-up table for aniso lighting
									
			mul r0.rgb, t3, t1	; diffuse map * aniso light
			mul r0.a,	v0,	t1	; IN.ShellBlend.a * diffuse fur mask.a
		};
		
		Texture[0] = <anisoMap>;
		Texture[1] = <mapShells>;
		//these two stages are reserved for the texm3x2 instructions
		//Texture[2]
		//Texture[3]
				
		ZWriteEnable=false;
		AlphaTestEnable=false;
		AlphaBlendEnable = true;
		SrcBlend = srcalpha;
		DestBlend = invsrcalpha;
		cullmode = cw;
			
		FogEnable=false;	//fog f*** up!
		//FogEnable=<FogEnabled>;
		//FogColor=<vFogColor>;
    } 
}
#endif	//defined(MESH_STANDARD) || defined(MESH_RIGID)

#if defined(MESH_WEIGHTED)
v2fFur VS_BaseMPS(a2vStandardMPS IN) 
{
    v2fFur OUT;
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w); 
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.TexAniso.xyz=float3(IN.vTexCoords.xy,0);
	OUT.TexDiffuse.xyz=OUT.TexAniso.xyz;
	
	// the single byte pr vertex of bandwidth should prove faster to transfer, than doing NrOfShells drawcalls
	OUT.ShellBlend=(1-IN.v4Diffuse)*0.5;
	
	//calc anisotropic
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	float3 vEyeDirOS=v4EyePosObject.xyz-v4PositionOut.xyz;
	float3 vLightDirOS=v4BonesLights11[1].xyz-v4PositionOut.xyz;
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	float3 vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+vEyeDirTS);
		
    return OUT;
}

technique FurShellsMPS < string Identifier="FurShellsMPS";//string Performance="Fastest"; 
> {
	pass Shell
    {		
		VertexShader = compile vs_1_1 VS_BaseMPS();
		PixelShader  = asm {	//compile ps_1_1 PS_Shells();
			ps.1.1
			
			tex t0 ; Contains direction of anisotropy in tangent space
			tex t1 ; diffuse base map w. shells hairinfo in alpha
			texm3x2pad t2, t0_bx2	; Perform first row of matrix multiply.
			texm3x2tex t3, t0_bx2	; Perform second row of matrix multiply to get a
									; 3-vector with which to sample texture 3, which is
									; a look-up table for aniso lighting
									
			mul r0.rgb, t3, t1	; diffuse map * aniso light
			mul r0.a,	v0,	t1	; IN.ShellBlend.a * diffuse fur mask.a
		};
		
		Texture[0] = <anisoMap>;
		Texture[1] = <mapShells>;
		//these two stages are reserved for the texm3x2 instructions
		//Texture[2]
		//Texture[3]
		
		ZWriteEnable=false;
		AlphaTestEnable=false;
		AlphaBlendEnable = true;
		SrcBlend = srcalpha;
		DestBlend = invsrcalpha;
		cullmode = cw;
					
		FogEnable=false;	//fog f*** up!
		//FogEnable=<FogEnabled>;
		//FogColor=<vFogColor>;
    } 
}
#endif	//SHELLSENABLED

#endif	//MESH_WEIGHTED
