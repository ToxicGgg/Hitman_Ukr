#include "common.fx"
/*
	Description:
		Skin shader for FFP
	Features:
		* Fixed function pipeline support
		* Support for skinned models
	Author:
		Kasper Storm Engelstoft
*/
// Application to Vertex defined by material class
struct a2vSkin {
    float4 v4Position	: POSITION;
    float3 v3Normal		: NORMAL;
	float4 v4Diffuse	: COLOR0;
	float4 vLightDir	: COLOR1;
	float2 v2TexCoord	: TEXCOORD0;
	float3 v3Tangent	: TANGENT;
	float3 v3Binormal	: BINORMAL;
};

struct a2vSkinMPS {
	float4	v4Position:	POSITION;
	float4	v4Weights:	BLENDWEIGHT;
	int4	v4Indices:	BLENDINDICES;
	float3	v3Normal:	NORMAL;
	float4	v4Diffuse:	COLOR0;
	float2	v2TexCoord:	TEXCOORD0;
	float3	v3Tangent:	TANGENT;
	float3	v3Binormal:	BINORMAL;
};

/****************************************************************
		Ambient pass
 ****************************************************************/
struct v2fSkinAmbient {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
	float vFog:			FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
v2fSkinAmbient Ambient_VS10(a2vSkin IN)
{
	v2fSkinAmbient OUT;
	
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	OUT.TexDiffuse=IN.v2TexCoord;
	OUT.Diffuse.rgb=CalculateDebugColor(IN.v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=CalculateAlpha(IN.v4Diffuse.a);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}
technique Ambient_VS11_FFP < string Identifier="Ambient"; string Performance="Fastest"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE2X;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE2X;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)

struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float vFog:				FOG;
};

v2fStandardAmbient10 AmbientMPS_VS10(a2vSkinMPS IN)
{
	v2fStandardAmbient10 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(IN.v3Normal,i,w);
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);

	// Calculate lighting
	float4 vDiffuse;
	vDiffuse.rgb=CalcBonesLight11(v3NormalOut,IN.v4Diffuse.rgb);
	vDiffuse.a = IN.v4Diffuse.a;
	CalculateColorVS11(OUT.Diffuse,vDiffuse);
	OUT.Diffuse *= 0.5f;
	OUT.vTexCoords=IN.v2TexCoord;
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	return OUT;
}

technique AmbientMPS_VS11_FFP < string Identifier="AmbientMPS"; string Performance="Fastest"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 AmbientMPS_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE2X;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE2X;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
// lighting pass
//////////////////////////////////////////////////////////////////

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

technique DiffuseBumpSpecularRimLight_VS20_PS20 < string Identifier="DiffuseBumpSpecularTransRimLight"; >
{
	pass p0 
	{
		VertexShader=compile vs_1_1 Ambient_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)

technique DiffuseBumpSpecularRimLightMPS_VS20_PS20 < string Identifier="DiffuseBumpSpecularTransRimLightMPS"; > 
{
	pass p0 
	{
		VertexShader=compile vs_1_1 AmbientMPS_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
