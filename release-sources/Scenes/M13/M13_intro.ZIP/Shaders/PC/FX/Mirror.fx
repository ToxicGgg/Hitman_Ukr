#include "StandardCommon.fx"

texture mapMirrorMask;
sampler samplerMirrorMask = sampler_state {
	texture =<mapMirrorMask>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=WRAP;
	AddressV=WRAP;
	AddressW=WRAP;
};

texture mapMirrorColor;
sampler samplerMirrorColor = sampler_state {
	texture =<mapMirrorColor>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=WRAP;
	AddressV=WRAP;
	AddressW=WRAP;
};

float4 gm_vMirrorBumpScale;

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardReflectionHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords:		TEXCOORD0;
	float4 vTexCoordsProj:	TEXCOORD1;
	float3 vLightDirTS:		TEXCOORD2;
	float3 vEyeDirTS:		TEXCOORD3;
	float3 vHalfDirTS:		TEXCOORD4;
	float4 Ambient:			TEXCOORD5;
	float vFog:				FOG;
};

v2fStandardReflectionHQ20 ReflectionHQ_VS20(a2vStandardHQ IN)
{
	v2fStandardReflectionHQ20 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+OUT.vEyeDirTS);

	OUT.Ambient=IN.v4Ambient*v4DiffuseColor;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a*v4Opacity.a;
#ifdef SPECULARENABLED
	OUT.Specular=IN.vLightCol*v4SpecularColor;
#else
	OUT.Specular=OUT.Diffuse;
#endif
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	OUT.vTexCoordsProj=mul(m44WorldViewProjScale,IN.v4Position);
	
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}
f2sStandard ReflectionHQ_PS20(v2fStandardReflectionHQ20 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
		
	float2 vCoords=IN.vTexCoordsProj.xy/IN.vTexCoordsProj.w;

	float4 vDiffuseColor=(IN.Ambient+saturate(dot(IN.vLightDirTS,v3BumpNormal))*IN.Diffuse)*2;
	float2 vReflectOffset=v3BumpNormal*gm_vMirrorBumpScale;
	float4 cReflect=tex2D(samplerReflection2D,vCoords+vReflectOffset);
	
#if defined(MIRRORENABLED) && defined(MIRRORMASKENABLED)
	float4 cMirror=tex2D(samplerDiffuse,vTexCoords);
	float4 cMask=tex2D(samplerMirrorMask,vTexCoords);
	float4 cColor=tex2D(samplerMirrorColor,vTexCoords);
	OUT.col.rgb=lerp(lerp(cMirror*vDiffuseColor,cReflect,cMask.a),cColor*vDiffuseColor,cColor.a);
	OUT.col.a=1;
#elif defined(MIRRORENABLED)
	float4 cMirror=tex2D(samplerDiffuse,vTexCoords);
	OUT.col.rgb=lerp(cReflect.rgb,cMirror.rgb*vDiffuseColor,cMirror.a);
	OUT.col.a=1;
#elif defined(MIRRORMASKENABLED)
	float4 cMask=tex2D(samplerMirrorMask,vTexCoords);
	float4 cColor=tex2D(samplerMirrorColor,vTexCoords);
	OUT.col.rgb=lerp(cColor.rgb*vDiffuseColor,cReflect.rgb,cMask.a);
	OUT.col.a=cColor.a;
#endif
	
	// Specular
#ifdef SPECULARENABLED
	float3 vHalfDir=normalize(IN.vHalfDirTS);
	//float3 vHalfDir=tosigned(tex2D(samplerCubeNormalizer,IN.vHalfDirTS));
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float vSpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=vSpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	OUT.col.rgb+=v3SpecularColor*2;
#endif
	
	return OUT;
}

technique ReflectionHQ_VS20_PS20 < string Identifier="Reflection"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 ReflectionHQ_VS20();
		PixelShader=compile ps_2_0 ReflectionHQ_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif
	}
}

struct v2fStandardReflection {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 vTexCoords:	TEXCOORD0;
	float4 vTexCoordsProj:	TEXCOORD2;
	float	vFog		: FOG;
};

v2fStandardReflection ReflectionHQ_VS11(a2vStandard IN)
{
	v2fStandardReflection OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,IN.v3Tangent,IN.v3Binormal,IN.v3Normal);
	
	float4 v4Position=IN.v4Position;
	float2 v2TexCoord=IN.vTexCoords;

	float3 vEyeDirOS=v4EyePosObject.xyz-v4Position.xyz;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a*v4Opacity.a*2;

	CalcTextureCoords(OUT.vTexCoords,v2TexCoord);
	OUT.vTexCoordsProj=mul((float4x4)m44WorldViewProjScale,v4Position);

	OUT.Position=mul(v4Position, (float4x4)m44ModelViewProj);
	CalculateFog(OUT.vFog, IN.v4Position.xyz);
	float3 v3BumpNormal=float3(0,0,1);
	return OUT;
}

technique Reflection  < string Identifier="Reflection"; string Performance="Fastest";> {
	pass MirrorPass
	{
		VertexShader=compile vs_1_1 ReflectionHQ_VS11();
		PixelShader=asm {//<ReflectionHQ_PS20>;
			ps.1.1

			//			v0					//Diffuse
			
			def		c1, 0.0, 0.0, 1.0, 1.0	//v3BumpNormal
			
		//	tex			t0					//vTexCoords	- mapDiffuse
		//	tex			t1					//vReflectOffset- projected texture lookup into reflection texture
			tex			t2					//vReflectOffset- projected texture lookup into reflection texture
		//	texcoord	t3					//vLightDirTS
			
		//	dp3		r0.rgb, t3.rgb, c1.rgb
		//	mad_x2	r0,		r0_sat, v0,		v1
		//	mul		t0.rgb, t0.rgb, r0.rgb
		//	lrp		r0,		1-t0.a,	t0,		t2
			
			//den ovenst�ende kode tilf�jer "skidt" til spejlet! t2 er den perfekte reflektion
			mov r0.rgb, t2
			+mov r0.a,	c1
		};

		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=InvSrcAlpha;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
#if FOGENABLED
		FogColor=<vFogColor>;
#endif

		//Texture[0] =<mapDiffuse>;
		MinFilter[0]=LINEAR;
		MagFilter[0]=LINEAR;
		MipFilter[0]=LINEAR;
		AddressU[0]=WRAP;
		AddressV[0]=WRAP;
		AddressW[0]=WRAP;

		Texture[2] =<mapReflection2D>;
		MinFilter[2]=LINEAR;
		MagFilter[2]=LINEAR;
		MipFilter[2]=LINEAR;
		AddressU[2]=CLAMP;
		AddressV[2]=CLAMP;
		AddressW[2]=CLAMP;
		TEXTURETRANSFORMFLAGS[2] = 256;	//D3DTTFF_PROJECTED
	}
}
