#include "StandardCommon.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardLighting20 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 Specular:			COLOR1;
	float4 vTexCoords:			TEXCOORD0;
	float3 TexLightDir:			TEXCOORD1;
	float4 TexLightDir2:		TEXCOORD2;
	float3 TexHalfAngleDir:		TEXCOORD3;
	float4 TexEyeDir:			TEXCOORD4;
	float4 vShadowCoords:		TEXCOORD5;
	float4 TexLightClip:		TEXCOORD6;
	float vFog:					FOG;
};

f2sStandard Lighting_PS20(v2fStandardLighting20 IN) {

	f2sStandard OUT;

	// Read base stuff
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.TexEyeDir);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords); 
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	
	float3 vLightAttenuation=CalculateLightIntensity(IN.TexLightClip,IN.TexLightDir2);
	float vShadowAttenuation=GetShadowMapPS3(IN.vShadowCoords,IN.TexEyeDir.w);
	//float vShadowAttenuation=1;
	
	float3 vResultColor;

	// Diffuse
	float3 v3LightDir=normalize(IN.TexLightDir.xyz);
	float v1DiffuseIntensity=saturate(dot(v3BumpNormal.xyz,v3LightDir));
	float3 v3DiffuseColor=v1DiffuseIntensity*IN.Diffuse.rgb*cTexel.rgb;
	vResultColor=v3DiffuseColor;
	
#ifdef SPECULARENABLED
	float3 v3HalfAngleVector=normalize(IN.TexHalfAngleDir);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float v1SpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,v3HalfAngleVector)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=v1SpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	vResultColor+=v3SpecularColor;
#endif

	OUT.col.rgb=vResultColor*vShadowAttenuation*vLightAttenuation;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardLighting20 Lighting_VS20(a2vStandardHQ IN) {
	v2fStandardLighting20 OUT;

#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float3 v3Tangent=lerp(tosigned(IN.v3Tangent),tosigned(IN.v3Tangent2),vTweenFactor);
	float3 v3Binormal=lerp(tosigned(IN.v3Binormal),tosigned(IN.v3Binormal2),vTweenFactor);
	float4 v4LightDir=lerp(tosigned(IN.vLightDir),tosigned(IN.vLightDir2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vVertexCol,IN.vVertexCol2,vTweenFactor);
	float4 v4LightCol=lerp(IN.vLightCol,IN.vLightCol2,vTweenFactor);
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float3 v3Tangent=tosigned(IN.v3Tangent);
	float3 v3Binormal=tosigned(IN.v3Binormal);
	float4 v4LightDir=tosigned(IN.vLightDir);
	float4 v4Diffuse=IN.vVertexCol;
	float4 v4LightCol=IN.vLightCol;
#endif

	CalcPosition(OUT.Position,v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3Tangent,v3Binormal,v3Normal);
	CalculateLightingVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,v4Diffuse);
	OUT.Diffuse.a*=CalculateAlphaFade(v4Position,v3Normal);
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,v4Position,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	return OUT;
}

technique Lighting_VS20_PS20 < string Identifier="Lighting"; > {
	
	pass p0 {
		VertexShader=compile vs_3_0 Lighting_VS20();
		PixelShader=compile ps_3_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardLighting20 LightingRigid_VS20(a2vStandardRigid IN) {
	v2fStandardLighting20 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	OUT.Diffuse.a*=CalculateAlphaFade(IN.v4Position,tosigned(IN.v3Normal));
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,IN.v4Position,tosigned(IN.v3Normal));
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	return OUT;
}

technique LightingRigid_VS20_PS20 < string Identifier="LightingRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_3_0 LightingRigid_VS20();
		PixelShader=compile ps_3_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif


#if defined(MESH_WEIGHTED)
v2fStandardLighting20 Lighting_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardLighting20 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,v4PositionOut,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,v4PositionOut,v3NormalOut);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	CalculateFog(OUT.vFog,v4PositionOut.xyz);

	return OUT;
}

technique Lighting_MPS_VS20_PS2 < string Identifier="LightingMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_3_0 Lighting_MPS_VS20();
		PixelShader=compile ps_3_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=false;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if 0
void CalculateTextureCoordsPS3(out float2 vTexCoordsOut, float4 vTexCoords, float3 vEyeDirTS) 
{
	static const int lNumSamples=32;
	
	f2sStandard OUT;
	
	float3 vEyeDir=vEyeDirTS/-vEyeDirTS.z;
	vEyeDir.xy*=vTexCoords.zw*vParallaxScale;
	//float3 vEyeDir=0.02*vEyeDirTS/-vEyeDirTS.z; // (x,y,-1)
	float3 vEnter=float3(vTexCoords.x,vTexCoords.y,1);
	float3 vLeave=float3(vEnter.x+vEyeDir.x,vEnter.y+vEyeDir.y,0);
	float3 vDt=(vLeave-vEnter)/(lNumSamples-1);
	
	float3 vBestSample=vLeave;
	float3 vSample=vLeave;
	float fHeight=tex2D(samplerNormal,vSample).a;
	float fDiff2=vSample.z-fHeight;
	for(int i=0; i<lNumSamples; i++) {
		vSample-=vDt;
		fHeight=tex2D(samplerParallax,saturate(vSample)).r;
		float fDiff1=vSample.z-fHeight;
		if(fDiff1>0 && fDiff2<0) {
			vBestSample=vSample+vDt*fDiff1/(fDiff1-fDiff2);
		}
		fDiff2=fDiff1;
	}
	vTexCoordsOut=vBestSample.xy;
	
	/*vSample.xyz=vEnter;
	vDt=-vDt;
	//while(fHeight<vSample.z) {
	for(int i=0; i<lNumSamples; i++) {
		vSample.xyz-=vDt;
		fHeight=tex2Dlod(samplerNormal,vSample);
		if(fHeight<vSample.z) {
			vTexCoordsOut=vSample.xy;
			return;
		}
	}
	vTexCoordsOut=vSample.xy;
	//cTexel=tex2D(samplerDiffuse,vSample);*/
}
#endif

