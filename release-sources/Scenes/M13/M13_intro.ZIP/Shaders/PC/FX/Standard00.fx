#include "StandardCommon.fx"

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

struct v2fStandardZFillHQ11 {
	float4 Position:		POSITION;
	float4 vTexCoords:		TEXCOORD0;
};

v2fStandardZFillHQ11 ZFillHQ_VS11(a2vStandardHQ IN)
{
	v2fStandardZFillHQ11 OUT;
	
	float4 OPOS = IN.v4Position;
	float3 ONOR = IN.v3Normal;

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	OPOS.xyz += fWobblePosAmplitude * IN.v3Normal * fWobble;
	ONOR.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	CalcPosition(OUT.Position,OPOS);
	
	return OUT;
}

technique ZFill_FFP < string Identifier="ZFill"; > 
{
	pass p0 
	{
		VertexShader=compile vs_1_1 ZFillHQ_VS11();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=TEXTURE;
		AlphaOp[0]=SELECTARG1;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=TEXTURE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
				
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=false;
	}
}
#endif

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
struct v2fStandardZPass {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
};

f2sStandard ZPass_PS11(v2fStandardZPass IN) 
{
	f2sStandard OUT;
	
	OUT.col=IN.Diffuse;
#ifdef BLENDENABLED
	float4 cTexel=tex2D(samplerDiffuse,IN.TexDiffuse.xy);
	OUT.col.a=CalculateAlpha(2*IN.Diffuse.a*cTexel.a);
#endif
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardZPass ZPass_VS11(a2vStandard IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	float f;
	CalculateFog(f,IN.v4Position.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;

	return OUT;
}

technique ZPass_VS11_PS11 < string Identifier="PostFilterZPass"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPass_VS11();
		PixelShader=NULL;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif

#ifdef BLENDENABLED
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=DIFFUSE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=MODULATE2X;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
#else
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=DIFFUSE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=SELECTARG1;
		AlphaArg1[0]=DIFFUSE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
#endif
	
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}

v2fStandardZPass ZPassAlpha_VS11(a2vStandardHQ IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	OUT.Diffuse.rgb=lerp(float3(0,0,0),vFogColor.rgb,1-IN.vVertexCol.a);
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;

	return OUT;
}

technique ZPass_VS11_PS11 < string Identifier="PostFilterZPassAlpha"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassAlpha_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardZPass ZPassRigid_VS11(a2vStandardRigid IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	float f;
	CalculateFog(f,IN.v4Position.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;

	return OUT;
}

technique ZPassRigid_VS11_PS11 < string Identifier="PostFilterZPassRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassRigid_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif


#ifdef MESH_WEIGHTED

v2fStandardZPass ZPassMPS_VS11(a2vStandardMPS IN)
{
	v2fStandardZPass OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);

	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.TexDiffuse=IN.vTexCoords;
	float f; 
	CalculateFog(f,v4PositionOut.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
	
	return OUT;
}

technique ZPassMPS_VS11_PS11 < string Identifier="PostFilterZPassMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassMPS_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float vFog:				FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardAmbient10 Ambient_VS11(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	OUT.vTexCoords=IN.vTexCoords;
	CalculateColorVS11(OUT.Diffuse,IN.vVertexCol);
	OUT.Diffuse *= 0.5f;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

technique Ambient_VS11_FFP < string Identifier="Ambient"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS11();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE2X;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE2X;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

#endif
#if defined(MESH_RIGID)

v2fStandardAmbient10 AmbientRigid_VS11(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	OUT.vTexCoords=IN.vTexCoords;
	CalculateColorVS11(OUT.Diffuse,IN.vVertexCol);
	OUT.Diffuse *= 0.5f;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	return OUT;
}

technique AmbientRigid_VS11_FFP < string Identifier="AmbientRigid"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientRigid_VS11();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardAmbient10 Ambient_MPS_VS11(a2vStandardMPS IN)
{
	v2fStandardAmbient10 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(IN.v3Normal,i,w);
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);

	float4 vDiffuse;
	vDiffuse.rgb=CalcBonesLight11(v3NormalOut,IN.v4Diffuse.rgb);
	vDiffuse.a = IN.v4Diffuse.a;
	CalculateColorVS11(OUT.Diffuse,vDiffuse);
	OUT.Diffuse *= 0.5f;
	
	OUT.vTexCoords=IN.vTexCoords;
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	return OUT;
}

technique Ambient_MPS_VS11_FFP < string Identifier="AmbientMPS"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_MPS_VS11();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE2X;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE2X;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

#define LIGHTING_RENDERSTATES \
	AlphaBlendEnable=true; \
	SrcBlend=SrcAlpha; \
	DestBlend=One; \
	AlphaTestEnable=<AlphaTestEnabled>; \
	AlphaRef=<AlphaTestValue>; \
	AlphaFunc=Greater; \
	CullMode=<Culling>; \
	ZFunc=LessEqual; \
	ZWriteEnable=<gi_iWriteZBuffer>; \
	FogEnable=<FogEnabled>; \
	FogColor=<vFogColor> \


struct v2fStandardLighting10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float vFog:				FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardLighting10 Lighting_VS11(a2vStandard IN) {
	v2fStandardLighting10 OUT;

#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vLightCol,IN.vLightCol2,vTweenFactor);//vVertexCol
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vLightCol;
#endif

	float3 v4LightDir=normalize(v4Position.xyz-v4LightPosObject.xyz);

	CalcPosition(OUT.Position,v4Position);
	OUT.vTexCoords=IN.vTexCoords;
	OUT.Diffuse.rgb=v4Diffuse.rgb*saturate(dot(v3Normal,v4LightDir.xyz));
#ifdef BLENDENABLED
	OUT.Diffuse.a=2*v4Diffuse.a*v4Opacity.a;
#else
	OUT.Diffuse.a=1;
#endif
	CalculateFog(OUT.vFog,v4Position.xyz);

	return OUT;
}

technique Lighting_FFP < string Identifier="Lighting"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Lighting_VS11();
		PixelShader=NULL;
				
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE2X;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE2X;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		ColorOp[2]=DISABLE;
		AlphaOp[2]=DISABLE;
		ColorOp[3]=DISABLE;
		AlphaOp[3]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		LIGHTING_RENDERSTATES;
	}
}
#endif
#if  defined(MESH_RIGID)
v2fStandardLighting10 LightingRigid_VS11(a2vStandard IN) {
	v2fStandardLighting10 OUT;

#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vLightCol,IN.vLightCol2,vTweenFactor);//vVertexCol
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vLightCol;
#endif

	float3 v4LightDir=normalize(v4Position.xyz-v4LightPosObject.xyz);

	CalcPosition(OUT.Position,v4Position);
	OUT.vTexCoords=IN.vTexCoords;
	OUT.Diffuse.rgb=v4Diffuse.rgb*saturate(dot(v3Normal,v4LightDir.xyz));
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a;
	CalculateFog(OUT.vFog,v4Position.xyz);
	OUT.Diffuse*=0.5;
	return OUT;
}
technique LightingRigid_FFP < string Identifier="LightingRigid"; > {
	pass p0 {
		VertexShader=compile vs_1_1 LightingRigid_VS11();
		PixelShader=NULL;
				
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		LIGHTING_RENDERSTATES;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardLighting10 Lighting_MPS_VS11(a2vStandardMPS IN)
{
	v2fStandardLighting10 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	
	CalcPosition(OUT.Position,v4PositionOut);
	OUT.vTexCoords=IN.vTexCoords;
//	OUT.Diffuse.rgb=IN.v4Diffuse.xzy*v4BonesLights11[2].xyz*saturate(dot(v3NormalOut,v4BonesLights11[1].xyz));
//	OUT.Diffuse.rgb+=v4BonesLights11[0];	//ambient
//	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
	float4 vDiffuse;
	vDiffuse.rgb=CalcBonesLight11(v3NormalOut,IN.v4Diffuse.rgb);
	vDiffuse.a = IN.v4Diffuse.a;
	CalculateColorVS11(OUT.Diffuse,vDiffuse);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);

	return OUT;
}

technique Lighting_MPS_FFP < string Identifier="LightingMPS"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Lighting_MPS_VS11();
		PixelShader=NULL;
			
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		
		ColorOp[1]=DISABLE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		LIGHTING_RENDERSTATES;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

#define ILLUMINATE_RENDERSTATES \
	AlphaBlendEnable=true; \
	SrcBlend=SrcAlpha; \
	DestBlend=One; \
	AlphaTestEnable=<AlphaTestEnabled>; \
	AlphaRef=<AlphaTestValue>; \
	AlphaFunc=Greater; \
	CullMode=<Culling>; \
	ZFunc=LessEqual; \
	FogEnable=<FogEnabled>; \
	FogColor=float4(0,0,0,1) \


	
struct v2fStandardIlluminate {
	float4 Position:			POSITION;
	float4 IlluminateColor:		COLOR0;
	float2 TexDiffuse1:			TEXCOORD0;
	float2 TexDiffuse2:			TEXCOORD1;
	float vFog:					FOG;
};

#if defined(ILLUMINATIONENABLED)

#if ( defined(MESH_STANDARD) || defined(MESH_TWEENED) )
v2fStandardIlluminate Illuminate_VS10(a2vStandard IN) {

	v2fStandardIlluminate OUT;

	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse1.xy,IN.vTexCoords);
	CalcTextureCoords(OUT.TexDiffuse2.xy,IN.vTexCoords);
	OUT.IlluminateColor.rgb=IN.vVertexCol.rgb*v4IlluminationColor.rgb;
	OUT.IlluminateColor.a=IN.vVertexCol.a*v4Opacity.a;	
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

//causes major gfx fuckups with the postfilters?
technique Illuminate_FFP < string Identifier="Illuminate"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Illuminate_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		Sampler[1]=<samplerIllumination>;
		
		ILLUMINATE_RENDERSTATES;
		
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		ColorOp[2]=DISABLE;
#ifdef BLENDENABLED
		AlphaOp[0]=MODULATE;
		AlphaArg0[0]=TEXTURE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=MODULATE;
		AlphaArg0[1]=TEXTURE;
		AlphaArg1[1]=CURRENT;
		AlphaOp[2]=DISABLE;
#else
		AlphaOp[0]=SUBTRACT;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=SELECTARG2;
		AlphaArg0[1]=DIFFUSE;
		AlphaArg1[1]=CURRENT|COMPLEMENT;
		AlphaOp[2]=DISABLE;
#endif
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardIlluminate IlluminateRigid_VS10(a2vStandardRigid IN) 
{
	v2fStandardIlluminate OUT;

	//OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse1.xy,IN.vTexCoords);
	CalcTextureCoords(OUT.TexDiffuse2.xy,IN.vTexCoords);
	OUT.IlluminateColor.rgb=IN.vVertexCol.rgb*v4IlluminationColor.rgb;
	OUT.IlluminateColor.a=IN.vVertexCol.a*v4Opacity.a;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

technique IlluminateRigid_FFP < string Identifier="IlluminateRigid"; > 
{	
	pass p0 
	{
		VertexShader=compile vs_1_1 IlluminateRigid_VS10();
		PixelShader=NULL;
		
		ILLUMINATE_RENDERSTATES;
		
		Sampler[0]=<samplerDiffuse>;
		Sampler[1]=<samplerIllumination>;
		
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		
		AlphaOp[0]=MODULATE;
		AlphaArg0[0]=TEXTURE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=MODULATE;
		AlphaArg0[1]=TEXTURE;
		AlphaArg1[1]=CURRENT;
			
		CONSTANT[2]=0xffffffff;
		AlphaOp[2]=LERP;
		AlphaArg0[2]=<BlendEnabled>;
		AlphaArg1[2]=CURRENT;
		AlphaArg2[2]=CONSTANT;
		
		ColorOp[2]=DISABLE;
		AlphaOp[3]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
	}
}
#endif

#endif	//ILLUMINATIONENABLED
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
#ifdef REFLECTIONENABLED

#define REFLECTION_RENDERSTATES \
	AlphaBlendEnable=true; \
	SrcBlend=One; \
	DestBlend=One; \
	CullMode=<Culling>; \
	ZFunc=Equal; \
	FogEnable=<FogEnabled>; \
	FogColor=float4(0,0,0,1) \
		
struct v2fStandardReflection 
{
	float4 Position:			POSITION;
	float4 Reflection:			COLOR0;
	float3 vTexCoordsCube:		TEXCOORD0;
	float2 vTexCoordsMask:		TEXCOORD1;
	float vFog:					FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardReflection Reflection_VS10(a2vStandard IN) {

	v2fStandardReflection OUT;
	
	float4 v4Position = IN.v4Position;
	float3 v3Normal = tosigned(IN.v3Normal);

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcPosition(OUT.Position,v4Position);
	CalcTextureCoords(OUT.vTexCoordsMask,IN.vTexCoords);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),v3Normal);
	
	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
//	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
//	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
//	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// And move colors over
	OUT.Reflection=v4ReflectionColor*IN.vLightCol;
	float3 eye = normalize(v4EyePosObject.xyz-v4Position.xyz);
	OUT.vTexCoordsCube=2*dot(eye,v3Normal)*v3Normal-eye;		//reflected vector for cubemap lookup
	OUT.vTexCoordsCube=mul(m33ObjToCubeSpace,OUT.vTexCoordsCube);	//transform

	return OUT;
}

technique Reflection_FFP < string Identifier="Reflection"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Reflection_VS10();
		PixelShader=NULL;//compile ps_2_0 Reflection_PS20();
		
		Sampler[0]=<samplerEnvironment>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerReflectionMask>;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		Sampler[2]=<samplerReflectionFallOff>;	//does gf4mx have 3 blendstages?
		ColorOp[2]=MODULATE;
		ColorArg1[2]=TEXTURE;
		ColorArg2[2]=CURRENT;
		ColorOp[3]=DISABLE;
		
		AlphaOp[0]=SUBTRACT;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=SELECTARG1;
		AlphaArg0[1]=CURRENT|COMPLEMENT;	//one
		AlphaArg1[1]=DIFFUSE;
		AlphaOp[2]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		REFLECTION_RENDERSTATES;
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardReflection ReflectionRigid_VS10(a2vStandardRigid IN) {

	v2fStandardReflection OUT;

	CalcTextureCoords(OUT.vTexCoordsMask,IN.vTexCoords);
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
//	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
//	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
//	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
		
	OUT.Reflection=v4ReflectionColor;
	float3 eye = normalize(v4EyePosObject.xyz-IN.v4Position.xyz);
	OUT.vTexCoordsCube=2*dot(eye,IN.v3Normal)*IN.v3Normal-eye;		//reflected vector for cubemap lookup
	OUT.vTexCoordsCube=mul(m33ObjToCubeSpace,OUT.vTexCoordsCube);	//transform

	return OUT;
}

technique ReflectionRigid_FFP < string Identifier="ReflectionRigid"; > 
{	
	pass p0 
	{
		VertexShader=compile vs_1_1 ReflectionRigid_VS10();
		PixelShader=NULL;	//compile ps_2_0 Reflection_PS20();
		
		Sampler[0]=<samplerEnvironment>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerReflectionMask>;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		Sampler[2]=<samplerReflectionFallOff>;	//does gf4mx have 3 blendstages?
		ColorOp[2]=MODULATE;
		ColorArg1[2]=TEXTURE;
		ColorArg2[2]=CURRENT;
		ColorOp[3]=DISABLE;
		
		AlphaOp[0]=SUBTRACT;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=SELECTARG1;
		AlphaArg0[1]=CURRENT|COMPLEMENT;	//one
		AlphaArg1[1]=DIFFUSE;
		AlphaOp[2]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		REFLECTION_RENDERSTATES;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardReflection ReflectionMPS_VS00(a2vStandardMPS IN) {

	v2fStandardReflection OUT;

	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	CalcTextureCoords(OUT.vTexCoordsMask,IN.vTexCoords);
	
	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
//	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
//	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
//	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
		
	OUT.Reflection=v4ReflectionColor;
	float3 eye = normalize(v4EyePosObject.xyz-IN.v4Position.xyz);
	OUT.vTexCoordsCube=2*dot(eye,IN.v3Normal)*IN.v3Normal-eye;		//reflected vector for cubemap lookup
	OUT.vTexCoordsCube=mul(m33ObjToCubeSpace,OUT.vTexCoordsCube);	//transform

	return OUT;
}

technique ReflectionMPS_VS00_PS00 < string Identifier="ReflectionMPS"; > {	
	pass p0 {
		VertexShader=compile vs_1_1 ReflectionMPS_VS00();
		PixelShader=NULL;
		
		Sampler[0]=<samplerEnvironment>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerReflectionMask>;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
		Sampler[2]=<samplerReflectionFallOff>;	//does gf4mx have 3 blendstages?
		ColorOp[2]=MODULATE;
		ColorArg1[2]=TEXTURE;
		ColorArg2[2]=CURRENT;
		ColorOp[3]=DISABLE;
		
		AlphaOp[0]=SUBTRACT;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		AlphaOp[1]=SELECTARG1;
		AlphaArg0[1]=CURRENT|COMPLEMENT;	//one
		AlphaArg1[1]=DIFFUSE;
		AlphaOp[2]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		REFLECTION_RENDERSTATES;
	}
}
#endif

#endif	//REFLECTIONENABLED