#include "StandardCommon.fx"

texture anisoMap;
sampler samplerAniso = sampler_state {
	texture =<anisoMap>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

float4 v4AnisoColor;

void CalculateLightingAnisoVS11(out float3 vLightDirOut, out float3 vHalfDirOut, out float3 vEyeDirOut,float4 vPosition, float3x3 m33TangentSpace) {

	// Calculate diffuse term
	float3 vLightDirObject=v4LightPosObject.xyz-vPosition.xyz;
	float3 v3EyeDirObject=v4EyePosObject.xyz-vPosition.xyz;
	float3 vLightDirTangentSpace=mul(m33TangentSpace,vLightDirObject);
	float3 vEyeDirTangentSpace=mul(m33TangentSpace,v3EyeDirObject);
	vLightDirOut=normalize(vLightDirTangentSpace.xyz);
	vEyeDirOut=normalize(vEyeDirTangentSpace.xyz);
	
	// Output half angle vector for specular term
	vHalfDirOut=normalize(vEyeDirTangentSpace)+vLightDirOut;
}

void CalculateColorAnisoVS(out float4 vDiffuseOut, out float4 vSpecularOut, float4 vDiffuseIn) {
	// Output diffuse color
	vDiffuseOut.rgb=v4LightAttributes.zzz*v4DiffuseColor.rgb*v4LightColor.rgb*vDiffuseIn.rgb;
#ifdef BLENDENABLED
	vDiffuseOut.a=vDiffuseIn.a*v4Opacity.a;
#else
	vDiffuseOut.a=1;
#endif
	// Output specular color
	vSpecularOut=v4LightAttributes.zzzz*v4AnisoColor*v4LightColor;
}

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

struct v2fStandardAmbientHQ11 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float2 vTexCoords0:		TEXCOORD0;
	float2 vTexCoords1:		TEXCOORD1;
	float2 AnisoTexCoords:	TEXCOORD2;
//	float4 Ambient:			TEXCOORD3;
	float vFog:				FOG;
};

v2fStandardAmbientHQ11 AmbientHQ_VS11(a2vStandard IN)
{
	v2fStandardAmbientHQ11 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
//	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	float3 vLightDirObject=v4LightPosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=vLightDirObject*v4LightAttributes.y;
//	OUT.Ambient=IN.v4Ambient*v4DiffuseColor;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a*v4Opacity.a*2;
	OUT.Specular=IN.vLightCol*v4AnisoColor;
	OUT.vTexCoords0=OUT.vTexCoords1=IN.vTexCoords;
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	OUT.AnisoTexCoords=float2(0,0);
	return OUT;
}

f2sStandard AmbientHQ_PS11(v2fStandardAmbientHQ11 IN) 
{
	f2sStandard OUT;
	float3 v3BumpNormal=CalculateBumpNormalPS(IN.vTexCoords0);
	float4 cTexel=tex2D(samplerDiffuse,IN.vTexCoords1);
	
	// Ambient
	OUT.col.rgb=0;//IN.Ambient.rgb*cTexel.rgb;
	float4 cAni=tex2D(samplerAniso,IN.AnisoTexCoords);
	float3 v3DiffuseColor=cAni.rgb*IN.Diffuse.rgb*cTexel.rgb;
	float3 v3SpecularColor=cAni.a*IN.Specular;
	OUT.col.rgb+=v3DiffuseColor+v3SpecularColor;
	
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	
	return OUT;
}

technique AmbientHQ_VS11_PS11 < string Identifier="Ambient"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS11();
		PixelShader=compile ps_1_1 AmbientHQ_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
// High quality ambient pass
//////////////////////////////////////////////////////////////////
#if defined(MESH_WEIGHTED)
struct v2fStandardAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float3 vLightDir1TS:	TEXCOORD1;
	float3 vHalfDir1TS:		TEXCOORD2;
	float vFog:				FOG;
};

v2fStandardAmbientMPSHQ AmbientHQ_MPS_VS11(a2vStandardMPS IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigend(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,v4PositionOut);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
	CalcBonesLightHQ11(OUT.vLightDir1TS,OUT.vHalfDir1TS,m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;

	CalculateFog(OUT.vFog,v4PositionOut.xyz);

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	
	return OUT;
}

f2sStandard AmbientHQ_MPS_PS11(v2fStandardAmbientMPSHQ IN) 
{
	f2sStandard OUT;
	float2 vTexCoords=IN.vTexCoords;
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDir1TS=IN.vLightDir1TS;
	OUT.col.rgb =v4BonesLights[1].rgb*saturate(dot(vLightDir1TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[6].rgb;
	OUT.col.rgb*=IN.Diffuse.rgb*cTexel.rgb*v4DiffuseColor*2;
	
#ifdef SPECULARENABLED		//this is not used anywhere, will fix it to ps.1.1 when needed
	float3 vHalfDir1=normalize(IN.vHalfDir1TS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float3 vSpecular1=v4BonesLights[1].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir1)),v4SpecularPower.x);	
	float3 v3SpecularColor=vSpecular1*v3SpecularMask*vSpecularLevel*v4SpecularColor*2;
	OUT.col.rgb+=v3SpecularColor;
#endif
	OUT.col.a=CalculateAlpha(cTexel.a);
	return OUT;
}

technique AmbientHQ_MPS_VS11_PS11 < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_MPS_VS11();
		PixelShader=compile ps_1_1 AmbientHQ_MPS_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

struct v2fStandardLighting11 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 Specular:			COLOR1;
	float2 vTexCoords:			TEXCOORD0;
	float2 AnisoTexCoords:		TEXCOORD1;
	float3 TexHalfAngleDir:		TEXCOORD3;
	float3 TexEyeDir:			TEXCOORD4;
	float vFog:					FOG;
};

f2sStandard DiffuseSpecularBump_PS11(v2fStandardLighting11 IN) {

	f2sStandard OUT;

	// Read base stuff
	float4 cTexel=tex2D(samplerDiffuse,IN.vTexCoords);
	float3 v3BumpNormal=CalculateBumpNormalPS11(IN.vTexCoords);
		
	float3 vResultColor;
	float4 cAni=tex2D(samplerAniso,IN.AnisoTexCoords);
	float3 v3DiffuseColor=cAni.rgb*IN.Diffuse.rgb*cTexel.rgb;
	float3 v3SpecularColor=cAni.a*IN.Specular;
	vResultColor=v3DiffuseColor+v3SpecularColor;

	OUT.col.rgb=vResultColor;//*vLightAttenuation*vShadowAttenuation
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
v2fStandardLighting11 DiffuseSpecular_VS11(a2vStandard IN) {
	v2fStandardLighting11 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	float3 TexLightDir;
	CalculateLightingAnisoVS11(TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir,IN.v4Position,m33TangentSpace);
	CalculateColorAnisoVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	float3 vLightDirTS=normalize(TexLightDir);
	float3 vHalfDirTS=normalize(OUT.TexHalfAngleDir);
	float vDiffuseIntensity=saturate(dot(float3(0,0,1),vLightDirTS));	//argh, no bump on the aniso!
	float vSpecularIntensity=saturate(dot(float3(0,0,1),vHalfDirTS));
	OUT.AnisoTexCoords= float2(vDiffuseIntensity,vSpecularIntensity);

	return OUT;
}

technique DiffuseSpecularBump_VS11_PS11 < string Identifier="Lighting"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 DiffuseSpecular_VS11();
		PixelShader=compile ps_1_1 DiffuseSpecularBump_PS11();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardLighting11 DiffuseSpecular_MPS_VS11(a2vStandardMPS IN)
{
	v2fStandardLighting11 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	float3 TexLightDir;
	CalculateLightingAnisoVS11(TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir,v4PositionOut,m33TangentSpace);
	CalculateColorAnisoVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	return OUT;
}

technique DiffuseSpecularBump_MPS_VS11_PS2 < string Identifier="LightingMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 DiffuseSpecular_MPS_VS11();
		PixelShader=compile ps_1_1 DiffuseSpecularBump_PS11();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
